// 用途：鸭鸭图解码页面前端逻辑，负责 UI、图片提取和解码流程控制。
import init, { DuckStreamDecoder, initializeRuntimeAuth } from "./pkg/duck_stream_wasm.js";

const WATERMARK_SKIP_W_RATIO = 0.40;
const WATERMARK_SKIP_H_RATIO = 0.08;
const IOS_JPEG_WARN_SIZE = 1024 * 1024;
const APP_VERSION = "web-1.0.0";

const fileInput = document.getElementById("fileInput");
const dropZone = document.getElementById("dropZone");
const fileListEl = document.getElementById("fileList");
const passwordInput = document.getElementById("password");
const decodeBtn = document.getElementById("decodeBtn");
const downloadAllBtn = document.getElementById("downloadAllBtn");
const logDiv = document.getElementById("log");
const resultArea = document.getElementById("resultArea");
const iosJpegWarn = document.getElementById("iosJpegWarn");
const iosJpegGuideBtn = document.getElementById("iosJpegGuideBtn");
const iosJpegContinueLink = document.getElementById("iosJpegContinueLink");
const decodeFileWarn = document.getElementById("decodeFileWarn");
const decodeFileWarnCloseBtn = document.getElementById("decodeFileWarnCloseBtn");

let selectedFiles = [];
let wasmReady = false;
let pakoLoadPromise = null;
const trackedObjectUrls = new Set();

function log(msg, type = "info") {
    const div = document.createElement("div");
    div.textContent = `[${new Date().toLocaleTimeString()}] ${msg}`;
    div.className = type;
    logDiv.appendChild(div);
    logDiv.scrollTop = logDiv.scrollHeight;
}

function yieldToBrowser() {
    return new Promise(resolve => setTimeout(resolve, 0));
}

function trackObjectUrl(url) {
    trackedObjectUrls.add(url);
    return url;
}

function revokeTrackedObjectUrls() {
    trackedObjectUrls.forEach(url => {
        try {
            URL.revokeObjectURL(url);
        } catch (e) {
        }
    });
    trackedObjectUrls.clear();
}

function resolveMimeByExt(ext) {
    if (ext === ".png") return "image/png";
    if (ext === ".jpg" || ext === ".jpeg") return "image/jpeg";
    if (ext === ".mp4") return "video/mp4";
    if (ext === ".txt") return "text/plain";
    if (ext === ".html") return "text/html";
    return "application/octet-stream";
}

function normalizeDecodeError(message) {
    if (!message) {
        return "解码失败，请检查文件是否有密码或密码是否正确，刷新页面重试。";
    }
    if (message === "Decoding failed: Could not find valid payload") {
        return "解码失败，请检查文件是否有密码或密码是否正确，刷新页面重试。";
    }
    if (message === "File is encrypted but no password provided") {
        return "解码失败，文件可能已加密，请输入密码后刷新页面重试。";
    }
    if (message === "Password verification failed") {
        return "解码失败，请检查密码是否正确，刷新页面重试。";
    }
    return message;
}

function buildOutputFileName(originName, ext) {
    const nameParts = originName.split(".");
    if (nameParts.length > 1) {
        nameParts.pop();
    }
    const baseName = nameParts.join(".");
    return {
        baseName,
        fileName: `extracted_${Date.now()}_${baseName}${ext}`,
    };
}

function formatSize(bytes) {
    if (bytes < 1024) return `${bytes} B`;
    if (bytes < 1024 * 1024) return `${(bytes / 1024).toFixed(2)} KB`;
    return `${(bytes / (1024 * 1024)).toFixed(2)} MB`;
}

function isIOS() {
    const ua = navigator.userAgent || navigator.vendor || window.opera;
    if (/iPad|iPhone|iPod/.test(ua)) return true;
    if (/Macintosh/.test(ua) && "ontouchend" in document) return true;
    return false;
}

function isBigDuckPng(file) {
    if (!file) return false;
    if (!isIOS()) return false;
    if (!file.type || !file.type.startsWith("image/")) return false;
    if (!file.name.toLowerCase().endsWith(".png")) return false;
    return file.size > 3 * 1024 * 1024;
}

function shouldShowIosJpegWarning(files) {
    if (!isIOS()) return false;
    for (const f of files) {
        const name = (f.name || "").toLowerCase();
        if ((name.endsWith(".jpg") || name.endsWith(".jpeg")) && f.size > 0 && f.size < IOS_JPEG_WARN_SIZE) {
            return true;
        }
    }
    return false;
}

function shouldShowDecodeFileWarning(files) {
    for (const f of files) {
        const name = (f.name || "").toLowerCase();
        if (!name.endsWith(".png")) {
            return true;
        }
        if (f.size > 0 && f.size < 200 * 1024) {
            return true;
        }
    }
    return false;
}

function showIosJpegWarning() {
    if (!iosJpegWarn) return;
    iosJpegWarn.classList.remove("hidden");
    iosJpegWarn.style.display = "flex";
    decodeBtn.disabled = true;
}

function hideIosJpegWarning() {
    if (!iosJpegWarn) return;
    iosJpegWarn.classList.add("hidden");
    iosJpegWarn.style.display = "none";
    if (selectedFiles.length > 0 && wasmReady) {
        decodeBtn.disabled = false;
    }
}

function showDecodeFileWarning() {
    if (!decodeFileWarn) return;
    decodeFileWarn.classList.remove("hidden");
    decodeFileWarn.style.display = "flex";
    decodeBtn.disabled = true;
}

function hideDecodeFileWarning() {
    if (!decodeFileWarn) return;
    decodeFileWarn.classList.add("hidden");
    decodeFileWarn.style.display = "none";
    if (selectedFiles.length > 0 && wasmReady && (!iosJpegWarn || iosJpegWarn.style.display === "none")) {
        decodeBtn.disabled = false;
    }
}

async function ensurePako() {
    if (window.pako) {
        return;
    }
    if (pakoLoadPromise) {
        return pakoLoadPromise;
    }
    pakoLoadPromise = new Promise((resolve, reject) => {
        const script = document.createElement("script");
        script.src = "https://cdn.jsdelivr.net/npm/pako@2.1.0/dist/pako.min.js";
        script.onload = () => window.pako ? resolve() : reject(new Error("pako 加载完成但未找到全局对象"));
        script.onerror = () => reject(new Error("pako 脚本加载失败"));
        document.head.appendChild(script);
    });
    return pakoLoadPromise;
}

async function initWasm() {
    if (location.protocol === "file:") {
        log("请通过本地 HTTP 服务访问本页面，直接打开 file:// 页面可能无法加载模块。", "error");
        return;
    }
    try {
        log("正在加载解码模块...", "info");
        await init(`./pkg/duck_stream_wasm_bg.wasm?v=${APP_VERSION}&et=${Date.now()}`);
        log("正在初始化...", "info");
        await initializeRuntimeAuth();
        wasmReady = true;
        if (selectedFiles.length > 0) {
            decodeBtn.disabled = false;
        }
        log("解码模块初始化成功", "success");
    } catch (e) {
        console.error(e);
        log(`解码模块初始化失败: ${e.message || e}`, "error");
    }
}

function readUint32BE(bytes) {
    return (
        (bytes[0] * 0x1000000) +
        ((bytes[1] << 16) >>> 0) +
        (bytes[2] << 8) +
        bytes[3]
    ) >>> 0;
}

function decodePngScanline(packetBuffer, rowBuffer, prevRow, stride, bpp) {
    const filterType = packetBuffer[0];
    if (filterType === 0) {
        for (let i = 0; i < stride; i++) rowBuffer[i] = packetBuffer[i + 1];
        return;
    }
    if (filterType === 1) {
        for (let i = 0; i < stride; i++) {
            const left = i >= bpp ? rowBuffer[i - bpp] : 0;
            rowBuffer[i] = (packetBuffer[i + 1] + left) & 0xFF;
        }
        return;
    }
    if (filterType === 2) {
        for (let i = 0; i < stride; i++) {
            rowBuffer[i] = (packetBuffer[i + 1] + prevRow[i]) & 0xFF;
        }
        return;
    }
    if (filterType === 3) {
        for (let i = 0; i < stride; i++) {
            const left = i >= bpp ? rowBuffer[i - bpp] : 0;
            const up = prevRow[i];
            rowBuffer[i] = (packetBuffer[i + 1] + Math.floor((left + up) / 2)) & 0xFF;
        }
        return;
    }
    if (filterType === 4) {
        for (let i = 0; i < stride; i++) {
            const left = i >= bpp ? rowBuffer[i - bpp] : 0;
            const up = prevRow[i];
            const upLeft = i >= bpp ? prevRow[i - bpp] : 0;
            const pa = Math.abs(up - upLeft);
            const pb = Math.abs(left - upLeft);
            const pc = Math.abs(left + up - 2 * upLeft);
            let pr;
            if (pa <= pb && pa <= pc) pr = left;
            else if (pb <= pc) pr = up;
            else pr = upLeft;
            rowBuffer[i] = (packetBuffer[i + 1] + pr) & 0xFF;
        }
        return;
    }
    throw new Error(`不支持的 PNG 滤波类型: ${filterType}`);
}

function appendScanlineToWasm(rowBuffer, y, width, skipW, skipH, channels, decoder) {
    const usableWidth = y < skipH ? (width - skipW) : width;
    const out = new Uint8Array(usableWidth * 3);
    let idx = 0;
    for (let x = 0; x < width; x++) {
        if (y < skipH && x < skipW) continue;
        const pos = x * channels;
        out[idx++] = rowBuffer[pos];
        out[idx++] = rowBuffer[pos + 1];
        out[idx++] = rowBuffer[pos + 2];
    }
    if (idx > 0) {
        decoder.feed_rgb_bytes(out);
    }
}

function appendRgbFromScanline(rowBuffer, y, width, skipW, skipH, channels, rgbBytes, rgbOffset) {
    for (let x = 0; x < width; x++) {
        if (y < skipH && x < skipW) continue;
        const pos = x * channels;
        rgbBytes[rgbOffset++] = rowBuffer[pos];
        rgbBytes[rgbOffset++] = rowBuffer[pos + 1];
        rgbBytes[rgbOffset++] = rowBuffer[pos + 2];
    }
    return rgbOffset;
}

async function extractRgbFromPngBytes(inputBytes, keepAllPixels) {
    let bytes = null;
    const idatParts = [];
    try {
        bytes = inputBytes;
        if (bytes.length < 8) {
            throw new Error("PNG 文件过小");
        }
        const sig = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
        for (let i = 0; i < sig.length; i++) {
            if (bytes[i] !== sig[i]) {
                throw new Error("PNG 头签名不匹配");
            }
        }
        let offset = 8;
        let width = 0;
        let height = 0;
        let bitDepth = 0;
        let colorType = 0;
        let interlace = 0;
        while (offset + 8 <= bytes.length) {
            const length = readUint32BE(bytes.subarray(offset, offset + 4));
            offset += 4;
            if (offset + 4 > bytes.length) break;
            const type = String.fromCharCode(bytes[offset], bytes[offset + 1], bytes[offset + 2], bytes[offset + 3]);
            offset += 4;
            if (offset + length + 4 > bytes.length) break;
            const data = bytes.subarray(offset, offset + length);
            offset += length + 4;
            if (type === "IHDR") {
                if (length < 13) throw new Error("IHDR 长度错误");
                width = readUint32BE(data.subarray(0, 4));
                height = readUint32BE(data.subarray(4, 8));
                bitDepth = data[8];
                colorType = data[9];
                interlace = data[12];
            } else if (type === "IDAT") {
                idatParts.push(data);
            } else if (type === "IEND") {
                break;
            }
        }
        if (!width || !height) throw new Error("未解析到宽高");
        if (bitDepth !== 8) throw new Error("仅支持 8 位 PNG");
        if (colorType !== 2 && colorType !== 6) throw new Error("仅支持 RGB/RGBA PNG");
        if (interlace !== 0) throw new Error("不支持隔行扫描 PNG");
        if (idatParts.length === 0) throw new Error("未找到 IDAT 数据");

        const channels = colorType === 2 ? 3 : 4;
        const bpp = channels;
        const stride = width * bpp;
        const rowPacketSize = stride + 1;
        const expected = rowPacketSize * height;
        const skipW = keepAllPixels ? 0 : Math.floor(width * WATERMARK_SKIP_W_RATIO);
        const skipH = keepAllPixels ? 0 : Math.floor(height * WATERMARK_SKIP_H_RATIO);
        const outputSize = (width * height - skipW * skipH) * 3;
        const rgbBytes = new Uint8Array(outputSize);
        let rgbOffset = 0;
        let producedBytes = 0;
        let rowsDecoded = 0;
        let packetOffset = 0;
        let streamError = null;
        let packetBuffer = new Uint8Array(rowPacketSize);
        let prevRow = new Uint8Array(stride);
        let rowBuffer = new Uint8Array(stride);

        await ensurePako();
        const inflator = new window.pako.Inflate();
        inflator.onData = (chunk) => {
            if (streamError) return;
            try {
                producedBytes += chunk.length;
                if (producedBytes > expected) {
                    throw new Error("解压后数据长度超出预期");
                }
                let pos = 0;
                while (pos < chunk.length) {
                    const need = rowPacketSize - packetOffset;
                    const take = Math.min(need, chunk.length - pos);
                    packetBuffer.set(chunk.subarray(pos, pos + take), packetOffset);
                    packetOffset += take;
                    pos += take;
                    if (packetOffset === rowPacketSize) {
                        decodePngScanline(packetBuffer, rowBuffer, prevRow, stride, bpp);
                        rgbOffset = appendRgbFromScanline(rowBuffer, rowsDecoded, width, skipW, skipH, channels, rgbBytes, rgbOffset);
                        rowsDecoded += 1;
                        packetOffset = 0;
                        const swap = prevRow;
                        prevRow = rowBuffer;
                        rowBuffer = swap;
                    }
                }
            } catch (e) {
                streamError = e;
            }
        };

        for (let i = 0; i < idatParts.length; i++) {
            inflator.push(idatParts[i], i === idatParts.length - 1);
            if (streamError) throw streamError;
            if (inflator.err) throw new Error(`zlib 解压失败: ${inflator.msg}`);
            if ((i & 7) === 7) {
                await yieldToBrowser();
            }
        }
        if (packetOffset !== 0 || producedBytes !== expected || rowsDecoded !== height) {
            throw new Error("PNG 扫描线解码不完整");
        }
        return rgbBytes;
    } finally {
        bytes = null;
        idatParts.length = 0;
        await yieldToBrowser();
    }
}

async function convertBinPngToBytes(binPngData) {
    try {
        let out = await extractRgbFromPngBytes(binPngData, true);
        binPngData = null;
        await yieldToBrowser();
        let end = out.length;
        while (end > 0 && out[end - 1] === 0) {
            end--;
        }
        if (end === out.length) {
            return out;
        }
        const trimmed = out.slice(0, end);
        out = null;
        await yieldToBrowser();
        return trimmed;
    } catch (binaryErr) {
        let imgBitmap = null;
        let canvas = null;
        try {
            const blob = new Blob([binPngData], { type: "image/png" });
            binPngData = null;
            await yieldToBrowser();
            imgBitmap = await createImageBitmap(blob, { colorSpaceConversion: "none" });
            canvas = document.createElement("canvas");
            canvas.width = imgBitmap.width;
            canvas.height = imgBitmap.height;
            const ctx = canvas.getContext("2d");
            if (!ctx) {
                throw new Error("浏览器无法创建 2D 画布上下文");
            }
            ctx.drawImage(imgBitmap, 0, 0);
            const imageData = ctx.getImageData(0, 0, canvas.width, canvas.height);
            const data = imageData.data;
            const rgbBuffer = new Uint8Array(canvas.width * canvas.height * 3);
            let idx = 0;
            for (let i = 0; i < data.length; i += 4) {
                rgbBuffer[idx++] = data[i];
                rgbBuffer[idx++] = data[i + 1];
                rgbBuffer[idx++] = data[i + 2];
            }
            let end = rgbBuffer.length;
            while (end > 0 && rgbBuffer[end - 1] === 0) {
                end--;
            }
            if (end === rgbBuffer.length) {
                return rgbBuffer;
            }
            const trimmed = rgbBuffer.slice(0, end);
            await yieldToBrowser();
            return trimmed;
        } finally {
            releaseCanvasResources(canvas, imgBitmap);
            await yieldToBrowser();
        }
    }
}

function releaseDecoderMemory(decoder) {
    if (!decoder) {
        return null;
    }
    try {
        decoder.release_memory();
    } catch (e) {
    }
    return null;
}

async function streamPngRowsToWasm(file, decoder, keepAllPixels) {
    await ensurePako();
    const chunkSize = 2 * 1024 * 1024;
    let pending = new Uint8Array(0);
    let fileOffset = 0;
    let signatureChecked = false;
    let sawIend = false;
    let width = 0;
    let height = 0;
    let bitDepth = 0;
    let colorType = 0;
    let interlace = 0;
    let channels = 0;
    let bpp = 0;
    let stride = 0;
    let rowPacketSize = 0;
    let skipW = 0;
    let skipH = 0;
    let packetOffset = 0;
    let rowsDecoded = 0;
    let packetBuffer = null;
    let prevRow = null;
    let rowBuffer = null;
    let inflator = null;
    let streamError = null;

    function ensureInflator() {
        if (inflator) return;
        inflator = new window.pako.Inflate();
        inflator.onData = (chunk) => {
            if (streamError) return;
            try {
                let pos = 0;
                while (pos < chunk.length) {
                    const need = rowPacketSize - packetOffset;
                    const take = Math.min(need, chunk.length - pos);
                    packetBuffer.set(chunk.subarray(pos, pos + take), packetOffset);
                    packetOffset += take;
                    pos += take;
                    if (packetOffset === rowPacketSize) {
                        decodePngScanline(packetBuffer, rowBuffer, prevRow, stride, bpp);
                        appendScanlineToWasm(rowBuffer, rowsDecoded, width, skipW, skipH, channels, decoder);
                        rowsDecoded += 1;
                        packetOffset = 0;
                        const swap = prevRow;
                        prevRow = rowBuffer;
                        rowBuffer = swap;
                    }
                }
            } catch (e) {
                streamError = e;
            }
        };
    }

    while (fileOffset < file.size) {
        const slice = file.slice(fileOffset, fileOffset + chunkSize);
        const current = new Uint8Array(await slice.arrayBuffer());
        fileOffset += slice.size;

        const merged = new Uint8Array(pending.length + current.length);
        merged.set(pending, 0);
        merged.set(current, pending.length);
        pending = merged;

        let offset = 0;
        if (!signatureChecked) {
            if (pending.length < 8) {
                continue;
            }
            const sig = [0x89, 0x50, 0x4E, 0x47, 0x0D, 0x0A, 0x1A, 0x0A];
            for (let i = 0; i < sig.length; i++) {
                if (pending[i] !== sig[i]) {
                    throw new Error("PNG 头签名不匹配");
                }
            }
            signatureChecked = true;
            offset = 8;
        }

        while (offset + 8 <= pending.length) {
            const length = readUint32BE(pending.subarray(offset, offset + 4));
            if (offset + 12 + length > pending.length) {
                break;
            }
            const type = String.fromCharCode(
                pending[offset + 4],
                pending[offset + 5],
                pending[offset + 6],
                pending[offset + 7]
            );
            const dataStart = offset + 8;
            const dataEnd = dataStart + length;
            const data = pending.subarray(dataStart, dataEnd);
            offset = dataEnd + 4;

            if (type === "IHDR") {
                width = readUint32BE(data.subarray(0, 4));
                height = readUint32BE(data.subarray(4, 8));
                bitDepth = data[8];
                colorType = data[9];
                interlace = data[12];
                if (bitDepth !== 8) throw new Error("仅支持 8 位 PNG");
                if (colorType !== 2 && colorType !== 6) throw new Error("仅支持 RGB/RGBA PNG");
                if (interlace !== 0) throw new Error("不支持隔行扫描 PNG");
                channels = colorType === 2 ? 3 : 4;
                bpp = channels;
                stride = width * bpp;
                rowPacketSize = stride + 1;
                skipW = keepAllPixels ? 0 : Math.floor(width * WATERMARK_SKIP_W_RATIO);
                skipH = keepAllPixels ? 0 : Math.floor(height * WATERMARK_SKIP_H_RATIO);
                packetBuffer = new Uint8Array(rowPacketSize);
                prevRow = new Uint8Array(stride);
                rowBuffer = new Uint8Array(stride);
            } else if (type === "IDAT") {
                ensureInflator();
                inflator.push(data, false);
                if (streamError) throw streamError;
                if (inflator.err) throw new Error(`zlib 解压失败: ${inflator.msg}`);
            } else if (type === "IEND") {
                sawIend = true;
            }
        }

        pending = pending.subarray(offset);
        await yieldToBrowser();
    }

    if (!sawIend) {
        throw new Error("PNG 数据未正常结束");
    }
    if (!inflator) {
        throw new Error("未找到 IDAT 数据");
    }
    inflator.push(new Uint8Array(0), true);
    if (streamError) throw streamError;
    if (inflator.err) throw new Error(`zlib 解压失败: ${inflator.msg}`);
    if (packetOffset !== 0 || rowsDecoded !== height) {
        throw new Error("PNG 扫描线解码不完整");
    }
}

function releaseCanvasResources(canvas, imgBitmap) {
    if (canvas) {
        canvas.width = 0;
        canvas.height = 0;
    }
    if (imgBitmap && typeof imgBitmap.close === "function") {
        try {
            imgBitmap.close();
        } catch (e) {
        }
    }
}

async function streamCanvasImageToWasm(file, decoder) {
    let imgBitmap = null;
    let canvas = null;
    try {
        imgBitmap = await createImageBitmap(file, { colorSpaceConversion: "none" });
        canvas = document.createElement("canvas");
        canvas.width = imgBitmap.width;
        const blockRows = 128;
        canvas.height = Math.min(blockRows, imgBitmap.height);
        const ctx = canvas.getContext("2d");
        if (!ctx) {
            throw new Error("浏览器无法创建 2D 画布上下文");
        }
        const w = imgBitmap.width;
        const h = imgBitmap.height;
        const skipW = Math.floor(w * WATERMARK_SKIP_W_RATIO);
        const skipH = Math.floor(h * WATERMARK_SKIP_H_RATIO);
        for (let startY = 0; startY < h; startY += blockRows) {
            const rows = Math.min(blockRows, h - startY);
            if (canvas.height !== rows) {
                canvas.height = rows;
            }
            ctx.clearRect(0, 0, w, rows);
            ctx.drawImage(imgBitmap, 0, startY, w, rows, 0, 0, w, rows);
            const imageData = ctx.getImageData(0, 0, w, rows);
            for (let rowInBlock = 0; rowInBlock < rows; rowInBlock++) {
                const y = startY + rowInBlock;
                const row = new Uint8Array((y < skipH ? (w - skipW) : w) * 3);
                let idx = 0;
                const rowBase = rowInBlock * w * 4;
                for (let x = 0; x < w; x++) {
                    if (y < skipH && x < skipW) continue;
                    const pos = rowBase + x * 4;
                    row[idx++] = imageData.data[pos];
                    row[idx++] = imageData.data[pos + 1];
                    row[idx++] = imageData.data[pos + 2];
                }
                decoder.feed_rgb_bytes(row);
            }
            await yieldToBrowser();
        }
    } finally {
        releaseCanvasResources(canvas, imgBitmap);
        await yieldToBrowser();
    }
}

async function streamRgbToWasm(file, decoder) {
    if (isBigDuckPng(file)) {
        log("检测到 iOS 大图，正在使用兼容模式处理", "info");
        await streamPngRowsToWasm(file, decoder, false);
        log("兼容模式处理完成", "success");
        return;
    }
    await streamCanvasImageToWasm(file, decoder);
}

function createExtraContentElement(htmlContent) {
    const container = document.createElement("div");
    container.className = "extra-content-container";
    container.style.marginTop = "15px";
    container.style.padding = "15px";
    container.style.border = "1px solid #ddd";
    container.style.borderRadius = "8px";
    container.style.backgroundColor = "#f9f9f9";
    container.style.textAlign = "left";

    const title = document.createElement("h3");
    title.textContent = "附加显示内容来自二维码图片内，请谨慎辨别内容安全性。";
    title.style.marginTop = "0";
    title.style.color = "#ff9800";
    title.style.fontSize = "12px";

    const contentDiv = document.createElement("div");
    contentDiv.innerHTML = htmlContent;
    contentDiv.querySelectorAll("img").forEach(img => {
        img.style.maxWidth = "200px";
        img.style.maxHeight = "200px";
        img.style.objectFit = "contain";
        img.style.display = "block";
        img.style.margin = "10px 0";
    });

    container.appendChild(title);
    container.appendChild(contentDiv);
    return container;
}

async function handleSuccess(meta, primaryDataInput, originName) {
    let primaryData = primaryDataInput;
    let ext = meta.primary_ext || ".bin";
    if (ext && !ext.startsWith(".")) {
        ext = `.${ext}`;
    }
    if (ext.toLowerCase().endsWith(".binpng")) {
        log("检测到 binpng 格式，正在还原为原始媒体...", "info");
        try {
            const restoredData = await convertBinPngToBytes(primaryData);
            primaryData = null;
            await yieldToBrowser();
            primaryData = restoredData;
            let convertedExt = ext.slice(0, -7);
            if (!convertedExt || convertedExt === ".") {
                convertedExt = ".mp4";
            }
            if (!convertedExt.startsWith(".")) {
                convertedExt = `.${convertedExt}`;
            }
            ext = convertedExt;
            log("binpng 还原成功", "success");
        } catch (e) {
            log(`binpng 还原失败: ${e.message}, 将保留原始文件`, "error");
        }
        await yieldToBrowser();
    }

    const fileInfo = buildOutputFileName(originName, ext);
    log(`解码成功! 原始扩展名: ${ext}`, "success");
    if (meta.matched_k != null) {
        log(`匹配到的压缩级别 K=${meta.matched_k}`, "info");
    }

    const itemContainer = document.createElement("div");
    itemContainer.className = "result-item";
    itemContainer.style.marginBottom = "20px";
    itemContainer.style.padding = "15px";
    itemContainer.style.border = "1px solid #e0e0e0";
    itemContainer.style.borderRadius = "8px";
    itemContainer.style.backgroundColor = "#fff";

    const link = document.createElement("a");
    link.className = "download-link";
    const url = trackObjectUrl(URL.createObjectURL(new Blob([primaryData], {
        type: resolveMimeByExt(ext),
    })));
    const primarySize = primaryData.length;
    primaryData = null;
    await yieldToBrowser();
    link.href = url;
    link.download = fileInfo.fileName;
    link.textContent = `点击下载提取的文件 (${formatSize(primarySize)}) - ${fileInfo.fileName}`;
    itemContainer.appendChild(link);

    if (meta.extra_html) {
        log("检测到二维码附加数据", "info");
        if (window.IS_QR_PAGE === true) {
            itemContainer.appendChild(createExtraContentElement(meta.extra_html));
        } else {
            const htmlContent = `<!DOCTYPE html>
<html>
<head>
<meta charset="UTF-8">
<meta name="viewport" content="width=device-width, initial-scale=1.0">
<title>附加内容 - ${originName}</title>
<style>
body { font-family: sans-serif; padding: 20px; max-width: 800px; margin: 0 auto; }
img { max-width: 100%; height: auto; }
</style>
</head>
<body>
    <h3 style="color: #ff9800;">附加显示内容来自二维码图片内，请谨慎辨别内容安全性。</h3>
    <div style="border: 1px solid #ddd; padding: 15px; border-radius: 8px; background: #f9f9f9;">
        ${meta.extra_html}
    </div>
</body>
</html>`;
            const extraBlob = new Blob([htmlContent], { type: "text/html" });
            const extraUrl = trackObjectUrl(URL.createObjectURL(extraBlob));
            const extraFileName = `${fileInfo.baseName}_extra.html`;
            const extraLink = document.createElement("a");
            extraLink.href = extraUrl;
            extraLink.download = extraFileName;
            extraLink.className = "download-link";
            extraLink.style.marginTop = "10px";
            extraLink.textContent = `点击下载附加数据 (${formatSize(extraBlob.size)}) - ${extraFileName}`;
            itemContainer.appendChild(extraLink);
        }
    }

    resultArea.appendChild(itemContainer);
}

function updateFileListUI() {
    fileListEl.innerHTML = "";
    if (selectedFiles.length === 0) {
        fileListEl.style.display = "none";
        return;
    }
    fileListEl.style.display = "block";
    selectedFiles.forEach((file, index) => {
        if (!file) return;
        const div = document.createElement("div");
        div.className = "file-item";
        div.id = `file-item-${index}`;
        div.innerHTML = `
            <span class="name">${file.name} (${formatSize(file.size)})</span>
            <span class="status pending">等待 (Pending)</span>
        `;
        fileListEl.appendChild(div);
    });
}

function updateFileStatus(index, status, msg) {
    const item = document.getElementById(`file-item-${index}`);
    if (!item) return;
    const statusEl = item.querySelector(".status");
    statusEl.className = `status ${status}`;
    statusEl.textContent = msg;
}

function handleFiles(files) {
    if (!files || files.length === 0) return;
    hideIosJpegWarning();
    hideDecodeFileWarning();
    selectedFiles = Array.from(files).filter(f => f.type.startsWith("image/"));
    updateFileListUI();
    if (selectedFiles.length > 0) {
        decodeBtn.textContent = `开始解码 ${selectedFiles.length} 个文件 (Decode ${selectedFiles.length} files)`;
        log(`已选择 ${selectedFiles.length} 个文件`);
    } else {
        decodeBtn.textContent = "开始批量解码 (Start Batch Decode)";
    }
    decodeBtn.disabled = selectedFiles.length === 0 || !wasmReady;
    if (selectedFiles.length > 0 && shouldShowDecodeFileWarning(selectedFiles)) {
        showDecodeFileWarning();
    } else if (selectedFiles.length > 0 && shouldShowIosJpegWarning(selectedFiles)) {
        showIosJpegWarning();
    }
}

dropZone.addEventListener("dragover", (e) => {
    e.preventDefault();
    dropZone.classList.add("dragover");
});

dropZone.addEventListener("dragleave", () => {
    dropZone.classList.remove("dragover");
});

dropZone.addEventListener("drop", (e) => {
    e.preventDefault();
    dropZone.classList.remove("dragover");
    handleFiles(e.dataTransfer.files);
});

fileInput.addEventListener("change", (e) => {
    handleFiles(e.target.files);
});

if (iosJpegGuideBtn) {
    iosJpegGuideBtn.addEventListener("click", () => {
        hideIosJpegWarning();
        window.location.href = "../jiaocheng.html";
    });
}

if (iosJpegContinueLink) {
    iosJpegContinueLink.addEventListener("click", (e) => {
        e.preventDefault();
        hideIosJpegWarning();
    });
}

if (decodeFileWarnCloseBtn) {
    decodeFileWarnCloseBtn.addEventListener("click", () => {
        hideDecodeFileWarning();
    });
}

decodeBtn.addEventListener("click", async () => {
    if (selectedFiles.length === 0 || !wasmReady) return;
    decodeBtn.disabled = true;
    downloadAllBtn.classList.add("hidden");
    revokeTrackedObjectUrls();
    resultArea.innerHTML = "";
    log("开始批量解码...", "info");

    for (let i = 0; i < selectedFiles.length; i++) {
        const file = selectedFiles[i];
        if (!file) continue;
        log(`正在处理 [${i + 1}/${selectedFiles.length}]: ${file.name}...`);
        updateFileStatus(i, "processing", "处理中 (Processing...)");
        try {
            let decoder = new DuckStreamDecoder(
                passwordInput.value,
                window.location.hostname || "",
                window.__DUCK_SECURITY_TOKEN__ || ""
            );
            try {
                await streamRgbToWasm(file, decoder);
                selectedFiles[i] = null;
                await yieldToBrowser();
                const meta = decoder.finish();
                if (!meta.success) {
                    decoder = releaseDecoderMemory(decoder);
                    const errorMessage = normalizeDecodeError(meta.error);
                    updateFileStatus(i, "error", "失败 (Failed)");
                    log(`${file.name} 解码失败: ${errorMessage}`, "error");
                    continue;
                }
                const primaryData = decoder.take_primary_data();
                // 主数据取到 JS 后，尽快清空 WASM 内部状态，降低 binpng 还原前的峰值内存。
                decoder = releaseDecoderMemory(decoder);
                await yieldToBrowser();
                await handleSuccess(meta, primaryData, file.name);
                updateFileStatus(i, "success", "成功 (Success)");
            } finally {
                decoder = releaseDecoderMemory(decoder);
                await yieldToBrowser();
            }
        } catch (e) {
            updateFileStatus(i, "error", "错误 (Error)");
            log(`${file.name} 发生错误: ${e.message}`, "error");
        }
        await yieldToBrowser();
    }

    decodeBtn.disabled = false;
    if (resultArea.children.length > 0) {
        downloadAllBtn.classList.remove("hidden");
    }
    log("批量解码完成。", "info");
});

downloadAllBtn.addEventListener("click", () => {
    const links = resultArea.querySelectorAll(".download-link");
    if (links.length === 0) return;
    log(`开始下载 ${links.length} 个文件...`, "info");
    links.forEach((link, i) => {
        setTimeout(() => link.click(), i * 500);
    });
});

initWasm();
